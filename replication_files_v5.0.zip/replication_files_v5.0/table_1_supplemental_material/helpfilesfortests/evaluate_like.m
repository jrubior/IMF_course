function like = evaluate_like(bbeta,xxi,n,z)




like = -n*log(bbeta);

tmp = 0;

for i=1:n
  
    tmp = tmp  + log(1 + xxi*z(i,1)/bbeta);
    
end

like = like - (1+(1/xxi))*tmp;


end