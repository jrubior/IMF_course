%==========================================================================
%% housekeeping
%==========================================================================
clear all;
clc;
close all;

%% Load the weights
currdir=pwd;
cd ..
get_help_dir_currdir=pwd;
load('figure_1_panel_b/results/matfiles/results.mat');
cd(currdir)


addpath('ChrisSimsOptimize')

global n z;

%% Set u threhold


uw = sort(uw);


N = size(uw,1);

u_thresholds = 1-[0.5;0.4;0.3;0.1;0.01];

store_bbetas = nan(size(u_thresholds,1),1);
store_xxis = nan(size(u_thresholds,1),1);
store_LR_stat = nan(size(u_thresholds,1),1);
store_size_z = nan(size(u_thresholds,1),1);
store_u_bar   = nan(size(u_thresholds,1),1);


for i_q=1:size(u_thresholds,1)
    
    u_bar = min(uw(u_thresholds(i_q,1)*N+1:end));
    
    z = uw(u_thresholds(i_q,1)*N+1:end)-u_bar;
    
    n = size(z,1);
    
    zbar = 0;
    
    for i=1:n
        
        
        zbar      = zbar + z(i,1)/n;
        
        
    end
    
    ttau0 = 1/zbar;
    
    xxi0= 0.75;
    bbeta0 = xxi0/ttau0;
    
    
    H0=eye(2)*1e-3;
    crit=1e-3;
    x0(1,1)=bbeta0;
    x0(2,1)=xxi0;
    nit=1000;
    rng('default'); % reinitialize the random number generator to its startup configuration
    rng(0);         % set seed
    [~,xh0,~,H0,~,~,~] = csminwel('obj_like_for_LR_test',x0,H0,[],crit,nit);
    crit=1e-5;
    [~,xh1,~,H1,~,~,~] = csminwel('obj_like_for_LR_test',xh0,H0,[],crit,nit);
    crit=1e-5;
    [fh_cand,xh,~,H,~,~,retcodeh] = csminwel('obj_like_for_LR_test',xh1,H1,[],crit,nit);

    
    bbeta_hat = xh(1);
    xxi_hat   = xh(2);
    

    
    if abs(xxi_hat-0.5)<=1e-7;
        % maximize likelihood assuming that the constraint is binding
        H0C=1e-3;
        crit=1e-3;
        x0C  =  bbeta0;
        [~,xh0C,~,H0C,~,~,~] = csminwel('obj_like_for_score_test',x0C,H0C,[],crit,nit);
        crit=1e-5;
        [~,xh1C,~,H1C,~,~,~] = csminwel('obj_like_for_score_test',xh0C,H0C,[],crit,nit);
        crit=1e-5;
        [fh,xh,~,H,~,~,retcodeh] = csminwel('obj_like_for_score_test',xh1C,H1C,[],crit,nit);
    
        if (fh*-1)>=(fh_cand*-1)
            bbeta_hat = xh(1);
            xxi_hat   = 0.5;
        else
            display('constraint is not binding')
  
        end
    end
    
    store_bbetas(i_q,1) = bbeta_hat;
    store_xxis(i_q,1)   = xxi_hat;
    
    H0=1e-3;
    crit=1e-3;
    x0=bbeta0;
    nit=1000;
    rng('default'); % reinitialize the random number generator to its startup configuration
    rng(0);         % set seed
    [~,xh0,~,H0,~,~,~] = csminwel('obj_like_for_score_test',x0,H0,[],crit,nit);
    crit=1e-5;
    [fh1,xh1,~,H1,~,~,~] = csminwel('obj_like_for_score_test',xh0,H0,[],crit,nit);
    crit=1e-5;
    [fh_R,xh_R,~,H_R,~,~,retcodeh_R] = csminwel('obj_like_for_score_test',xh1,H1,[],crit,nit);
    

   

 
    LR = 2*((fh*-1) - (fh_R*-1));
  
    
    store_LR_stat(i_q,1)=LR;
    
    store_size_z(i_q,1) = n;

    store_u_bar(i_q,1) = u_bar;
    
end

savefile='matfiles/LR.mat';
save(savefile,'store_LR_stat');

delete *.mat;
delete *.dat;
