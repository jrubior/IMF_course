%==========================================================================
%% housekeeping
%==========================================================================
clear all;
close all;
clc;

%% Load the weights
currdir=pwd;
cd ..
get_help_dir_currdir=pwd;
load('figure_1_panel_b/results/matfiles/results.mat');
cd(currdir)


addpath('ChrisSimsOptimize')

global n z;

%% Set u threhold


uw = sort(uw);


N = size(uw,1);

u_thresholds = 1-[0.5;0.4;0.3;0.1;0.01];

store_bbetas = nan(size(u_thresholds,1),1);
store_score_stat = nan(size(u_thresholds,1),1);
store_size_z = nan(size(u_thresholds,1),1);
store_u_bar   = nan(size(u_thresholds,1),1);


for i_q=1:size(u_thresholds,1)
    
    u_bar = min(uw(u_thresholds(i_q,1)*N+1:end));
    
    z = uw(u_thresholds(i_q,1)*N+1:end)-u_bar;
    
    n = size(z,1);
    
    zbar = 0;
    
    for i=1:n
        
        
        zbar      = zbar + z(i,1)/n;
        
        
    end
    
    ttau0 = 1/zbar;
    
    xxi0= 0.5;
    bbeta0 = xxi0/ttau0;
    
    
    H0=1e-3;
    crit=1e-3;
    x0=bbeta0;
    nit=1000;
    rng('default'); % reinitialize the random number generator to its startup configuration
    rng(0);         % set seed
    [~,xh0,~,H0,~,~,~] = csminwel('obj_like_for_score_test',x0,H0,[],crit,nit);
    crit=1e-5;
    [~,xh1,~,H1,~,~,~] = csminwel('obj_like_for_score_test',xh0,H0,[],crit,nit);
    crit=1e-5;
    [fh,xh,~,H,~,~,retcodeh] = csminwel('obj_like_for_score_test',xh1,H1,[],crit,nit);
    
    bbeta_hat = xh;
    
    store_bbetas(i_q,1)=bbeta_hat;
    
    s_xxi_r = 0;
    
    for i=1:n
        
        s_xxi_r = s_xxi_r + 4*log(1+(z(i,1)/(2*bbeta_hat))) - (3/bbeta_hat)*(z(i,1)/(1+(z(i,1)/(2*bbeta_hat))));
    end
    
    s_xxi_star =  s_xxi_r/sqrt(2*n);
    
    store_score_stat(i_q,1)=s_xxi_star;
    
     store_size_z(i_q,1) = n;

    store_u_bar(i_q,1) = u_bar;
    
end

savefile='matfiles/score.mat';
save(savefile,'store_score_stat');

delete *.mat;
delete *.dat;
