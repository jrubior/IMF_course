function f = obj_like_for_score_test(x)


global n z;


bbeta = x;
xxi  = 0.5;


if bbeta>0 && xxi<=1 && min(1 + xxi*z/bbeta)>0

    
f = evaluate_like(bbeta,xxi,n,z)*-1;


else
    
    f= 1e9;
    
end

end
