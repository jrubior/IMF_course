%% preliminaries

if strcmp(conjugate,'structural')==1
    storevegphiZ=storevegfhZ;
    storevegphiZOneSidedND=storevegfhZOneSidedND;
end


storevegphiZ           = storevegphiZ(storevegphiZ~=0);
storevegphiZOneSidedND = storevegphiZOneSidedND(storevegphiZOneSidedND~=0);


w  = uw/sum(uw);
ne = floor(1/sum(w.^2));

ntoplot     = min(maxdraws,ne);

storevegphiZ           = storevegphiZ(1:ntoplot,1);
storevegphiZOneSidedND = storevegphiZOneSidedND(1:ntoplot,1);

diffvegphiZ = ((exp(storevegphiZOneSidedND-storevegphiZ(1:ntoplot,1)))-1)*100;


   
%% histogram
fontsize    = 8; % 11
ftsizetitle = 8; % 14
legftsize   = 8; % 11
axiswidth   = 1;

lbq = 0.005;
ubq = 0.995;
nbins = 42;
color_histogram_bars=[0         0    0.5430];
close all
hFig = figure(1);
set(hFig, 'Position', [20 20 350 175])
q1=quantile(diffvegphiZ,lbq);
q2=quantile(diffvegphiZ,ubq);
q = max(abs(q1),abs(q2));
edges = [-(q+0.25*q) -q:(q2-q1)/nbins:q q+0.25*q];
h=histogram(diffvegphiZ,edges,'normalization','probability');
h.FaceColor = color_histogram_bars;
h.EdgeColor = color_histogram_bars;
h.LineWidth = 1;
h.FaceAlpha = 0.5;
set(gca,'XTick',[-0.01;-0.0075;-0.005;-0.0025;0;0.0025;0.005;0.0075;0.01])
%set(gca,'XTickLabels',[{'-1x10^{-2}' '-7.5x10^{-3}' '-5x10^{-3}' '0' ' 5x10^{-3}' ' 7.5x10^{-3}' ' 1x10^{-2}'}])
set(gca,'YTick',[0 0.02 0.04 0.06 0.08 0.10],'linewidth',2)
ylim([0 0.10])
xlim([-0.01 0.01])
xlabel('Percent')
set(gca,'Fontsize',fontsize)
grid on
box off
set(gca,'LineWidth',axiswidth)
set(gca,'Gridalpha',0.05);
title('$v_{(g \circ f_{h})|\mathcal{Z}}({\bf A}_0, {\bf A}_+)$','Interpreter','latex','FontSize',ftsizetitle)

set(gcf, 'PaperPositionMode', 'auto');
print('results/pngfiles/figure_1_supplemental_material.png','-dpng');
print('results/epsfiles/figure_1_supplemental_material.eps','-depsc');




