%% store results and plot IRFs
addpath('results/plothelpfunctions'); 


close all
fontsizetitle  = 8;
fontsizeaxes   = 8;
fontsizelegend = 8;
axiswidth      = 1;
linewidthsize = 1;

scale = 1;
color_for_lines=[0         0    0.5430];%[0.6602    0.6602    0.6602];%

axis_for_plot=[-0.0015 -0.001 -0.0005 0 0.0005];
my_axis=[0 40 axis_for_plot(1) axis_for_plot(end)];
hFig = figure('name','Figure 5','NumberTitle','off');
set(hFig, 'Position', [0 20 500 250]) %set(hFig, 'Position', [0 20 750 325])
% TFP
subplot(2,3,1)
tfpq16             = squeeze(Ltildeq16(1:horizon+1,1,1))*scale;
tfpOneSidedNDq16   = squeeze(LtildeOneSidedNDq16(1:horizon+1,1,1))*scale;
tfpq50             = squeeze(Ltildeq50(1:horizon+1,1,1))*scale;
tfpOneSidedNDq50   = squeeze(LtildeOneSidedNDq50(1:horizon+1,1,1))*scale;
tfpq84             = squeeze(Ltildeq84(1:horizon+1,1,1))*scale;
tfpOneSidedNDq84   = squeeze(LtildeOneSidedNDq84(1:horizon+1,1,1))*scale;
ratioq16           = ((tfpOneSidedNDq16-tfpq16));
ratioq50           = ((tfpOneSidedNDq50-tfpq50));
ratioq84           = ((tfpOneSidedNDq84-tfpq84));

plot(ratioq16,'color',color_for_lines,'LineStyle','--','linewidth',linewidthsize)
hold on
plot(ratioq50,'color',color_for_lines,'LineStyle','-','linewidth',linewidthsize)
hold on
plot(ratioq84,'color',color_for_lines,'LineStyle','-.','linewidth',linewidthsize)
ylabel('Percentage points')
xlabel('Quarters')
leg=legend('16th quantile','Median','84th quantile');
set(leg,'Location','SouthEast')
legend boxoff
set(gca,'XTick',[0;10;20;30;40])
set(gca,'YTick',axis_for_plot)
set(gca,'LineWidth',2.0)
set(gca,'FontSize',fontsizeaxes)
axis(my_axis)
grid on
box off
set(gca,'LineWidth',axiswidth)
set(gca,'Gridalpha',0.05);
title('  Adjusted TFP','Interpreter','tex','FontSize',fontsizetitle)

% Stock Price
axis_for_plot=[-0.009 -0.006 -0.003 0 0.003];
my_axis=[0 40 axis_for_plot(1) axis_for_plot(end)];
subplot(2,3,2)
spq16            = squeeze(Ltildeq16(1:horizon+1,2,1))*scale;
spOneSidedNDq16  = squeeze(LtildeOneSidedNDq16(1:horizon+1,2,1))*scale;
spq50            = squeeze(Ltildeq50(1:horizon+1,2,1))*scale;
spOneSidedNDq50  = squeeze(LtildeOneSidedNDq50(1:horizon+1,2,1))*scale;
spq84            = squeeze(Ltildeq84(1:horizon+1,2,1))*scale;
spOneSidedNDq84  = squeeze(LtildeOneSidedNDq84(1:horizon+1,2,1))*scale;
ratioq16         = ((spOneSidedNDq16-spq16));
ratioq50         = ((spOneSidedNDq50-spq50));
ratioq84         = ((spOneSidedNDq84-spq84));

plot(ratioq16,'color',color_for_lines,'LineStyle','--','linewidth',linewidthsize)
hold on
plot(ratioq50,'color',color_for_lines,'LineStyle','-','linewidth',linewidthsize)
hold on
plot(ratioq84,'color',color_for_lines,'LineStyle','-.','linewidth',linewidthsize)
ylabel('Percentage points')
xlabel('Quarters')
set(gca,'XTick',[0;10;20;30;40])
%set(gca,'YTick',[-0.03 -0.02 -0.01 0 0.01])
%set(gca,'YTick',[-0.05 -0.025 0 0.025 0.05])
set(gca,'YTick',axis_for_plot)
set(gca,'LineWidth',2.0)
set(gca,'FontSize',fontsizeaxes)
%axis([0 40 -3*10^-2 1*10^-2])
% axis([0 40 -0.05 0.05])
axis(my_axis)
grid on
box off
set(gca,'LineWidth',axiswidth)
set(gca,'Gridalpha',0.05);
title(' Stock Prices','Interpreter','tex','FontSize',fontsizetitle)

% Consumption
axis_for_plot=[-0.0015 -0.001 -0.0005 0 0.0005];
my_axis=[0 40 axis_for_plot(1) axis_for_plot(end)];
subplot(2,3,3)
cq16             = squeeze(Ltildeq16(1:horizon+1,3,1))*scale;
cOneSidedNDq16   = squeeze(LtildeOneSidedNDq16(1:horizon+1,3,1))*scale;
cq50             = squeeze(Ltildeq50(1:horizon+1,3,1))*scale;
cOneSidedNDq50   = squeeze(LtildeOneSidedNDq50(1:horizon+1,3,1))*scale;
cq84             = squeeze(Ltildeq84(1:horizon+1,3,1))*scale;
cOneSidedNDq84   = squeeze(LtildeOneSidedNDq84(1:horizon+1,3,1))*scale;
ratioq16         = ((cOneSidedNDq16-cq16));
ratioq50         = ((cOneSidedNDq50-cq50));
ratioq84         = ((cOneSidedNDq84-cq84));
plot(ratioq16,'color',color_for_lines,'LineStyle','--','linewidth',linewidthsize)
hold on
plot(ratioq50,'color',color_for_lines,'LineStyle','-','linewidth',linewidthsize)
hold on
plot(ratioq84,'color',color_for_lines,'LineStyle','-.','linewidth',linewidthsize)
ylabel('Percentage points')
xlabel('Quarters')
set(gca,'XTick',[0;10;20;30;40])
%set(gca,'YTick',[-3*10^-3 -2*10^-3 -1*10^-3 0 1*10^-3])
%set(gca,'YTick',[-0.05 -0.025 0 0.025 0.05])
set(gca,'YTick',axis_for_plot)
set(gca,'LineWidth',2.0)
set(gca,'FontSize',fontsizeaxes)
%axis([0 40 -3*10^-3 1*10^-3])
% axis([0 40 -0.05 0.05])
axis(my_axis)
grid on
box off
set(gca,'LineWidth',axiswidth)
set(gca,'Gridalpha',0.05);
title('  Consumption','Interpreter','tex','FontSize',fontsizetitle)


% real interest rate
axis_for_plot=[-0.0045 -0.003 -0.0015 0 0.0015];
my_axis=[0 40 axis_for_plot(1) axis_for_plot(end)];
subplot(2,3,4)
rrq16            = squeeze(Ltildeq16(1:horizon+1,4,1))*scale;
rrOneSidedNDq16  = squeeze(LtildeOneSidedNDq16(1:horizon+1,4,1))*scale;
rrq50            = squeeze(Ltildeq50(1:horizon+1,4,1))*scale;
rrOneSidedNDq50  = squeeze(LtildeOneSidedNDq50(1:horizon+1,4,1))*scale;
rrq84            = squeeze(Ltildeq84(1:horizon+1,4,1))*scale;
rrOneSidedNDq84  = squeeze(LtildeOneSidedNDq84(1:horizon+1,4,1))*scale;
ratioq16         = ((rrOneSidedNDq16-rrq16));
ratioq50         = ((rrOneSidedNDq50-rrq50));
ratioq84         = ((rrOneSidedNDq84-rrq84));
plot(ratioq16,'color',color_for_lines,'LineStyle','--','linewidth',linewidthsize)
hold on
plot(ratioq50,'color',color_for_lines,'LineStyle','-','linewidth',linewidthsize)
hold on
plot(ratioq84,'color',color_for_lines,'LineStyle','-.','linewidth',linewidthsize)
ylabel('Percentage points')
xlabel('Quarters')
set(gca,'XTick',[0;10;20;30;40])
%set(gca,'YTick',[-9*10^-3 -6*10^-3 -3*10^-3 0 3*10^-3])
%set(gca,'YTickLabels',[{'-9x10^{-3}' '-6x10^{-3}' '-3x10^{-3}' '0' '3x10^{-3}'}])
%set(gca,'YTick',[-0.05 -0.025 0 0.025 0.05])
set(gca,'YTick',axis_for_plot)
set(gca,'LineWidth',2.0)
set(gca,'FontSize',fontsizeaxes)
%axis([0 40 -9*10^-3 3*10^-3])
% axis([0 40 -0.05 0.05])
axis(my_axis)
grid on
box off
set(gca,'LineWidth',axiswidth)
set(gca,'Gridalpha',0.05);
title('          Real Interest Rate','Interpreter','tex','FontSize',fontsizetitle)


% Hours Worked
axis_for_plot=[-0.002 -0.001 0 0.001 0.002];
my_axis=[0 40 axis_for_plot(1) axis_for_plot(end)];
subplot(2,3,5)
hwq16            = squeeze(Ltildeq16(1:horizon+1,5,1))*scale;
hwOneSidedNDq16  = squeeze(LtildeOneSidedNDq16(1:horizon+1,5,1))*scale;
hwq50            = squeeze(Ltildeq50(1:horizon+1,5,1))*scale;
hwOneSidedNDq50  = squeeze(LtildeOneSidedNDq50(1:horizon+1,5,1))*scale;
hwq84            = squeeze(Ltildeq84(1:horizon+1,5,1))*scale;
hwOneSidedNDq84  = squeeze(LtildeOneSidedNDq84(1:horizon+1,5,1))*scale;
ratioq16         = ((hwOneSidedNDq16-hwq16));
ratioq50         = ((hwOneSidedNDq50-hwq50));
ratioq84         = ((hwOneSidedNDq84-hwq84));
plot(ratioq16,'color',color_for_lines,'LineStyle','--','linewidth',linewidthsize)
hold on
plot(ratioq50,'color',color_for_lines,'LineStyle','-','linewidth',linewidthsize)
hold on
plot(ratioq84,'color',color_for_lines,'LineStyle','-.','linewidth',linewidthsize)
ylabel('Percentage points')
xlabel('Quarters')
set(gca,'XTick',[0;10;20;30;40])
%set(gca,'YTick',[-3*10^-3 -2*10^-3 -1*10^-3 0 1*10^-3])
%set(gca,'YTickLabels',[{'-3x10^{-3}' '-2x10^{-3}' '-1x10^{-3}'  '0' '1x10^{-3}'}])
%set(gca,'YTick',[-0.05 -0.025 0 0.025 0.05])
set(gca,'YTick',axis_for_plot)
set(gca,'LineWidth',2.0)
set(gca,'FontSize',fontsizeaxes)
%axis([0 40 -3*10^-3 1*10^-3])
% axis([0 40 -0.05 0.05])
axis(my_axis)
grid on
box off
set(leg,'Fontsize',fontsizelegend);
set(leg,'Position',[0.697379807692308 0.243161073954792 0.161538461538462 0.135384615384615]);
set(gca,'LineWidth',axiswidth)
set(gca,'Gridalpha',0.05);
title('    Hours Worked','Interpreter','tex','FontSize',fontsizetitle)

set(gcf, 'PaperPositionMode', 'auto');
print('results/pngfiles/figure_2_supplemental_material.png','-dpng')
print('results/epsfiles/figure_2_supplemental_material.eps','-depsc')




